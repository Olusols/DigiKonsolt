from django.apps import AppConfig


class KonsoltConfig(AppConfig):
    name = 'Konsolt'
